using UnityEngine;

public class UIManager : MonoBehaviour
{
    // Called when the Enter button is activated
    public void OnEnterVR()
    {
        // Hide this UI (we assume the Canvas is parented to this GameObject)
        gameObject.SetActive(false);
    }

    // You can add more methods here later for Guide, Quit, Restart, etc.
}
